﻿using QuanLyQuanCafe.DAO;
using QuanLyQuanCafe.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanCafe
{
    public partial class fAdmin : Form
    {
        BindingSource foodList = new BindingSource();
        BindingSource categoryList = new BindingSource();
        BindingSource tableList = new BindingSource();
        BindingSource accountList = new BindingSource();

        public Account loginAccount;
        public fAdmin()
        {
            InitializeComponent();
            Load();
            cbxTableStatus.Items.Add("Có người");
            cbxTableStatus.Items.Add("Trống");
          
        }

        List<Food> SearchFoodByName(string name)
        {
            List<Food> listFood = FoodDAO.Instance.SearchFoodByName(name); 

            return listFood;
        }
        void Load()
        {
            dgvFood.DataSource = foodList;
            dgvCategory.DataSource = categoryList;
            dgvTable.DataSource = tableList;
            dgvAccount.DataSource = accountList;
            LoadDateTimePickerBill();
            LoadListBillByDate(dtpkFromday.Value, dtpkToDate.Value);
            LoadListFood();
            LoadListFoodCategory();
            LoadCategoryintoCombobox(cbFoodCategory);
            //LoadStatusIntoCombobox(cbxTableStatus);
            LoadListTable();
            LoadAccount();
            AddFoodBinding();
            AddCategoryBinding();
            AddTableBinding();
            AddAccountBinding();
           
        }
        void LoadDateTimePickerBill()
        {
            DateTime today = DateTime.Now;
            dtpkFromday.Value = new DateTime(today.Year, today.Month, 1);
            dtpkToDate.Value = dtpkFromday.Value.AddMonths(1).AddDays(-1);
        }
        #region methods
        void LoadListBillByDate(DateTime checkIn, DateTime checkOut)
        {
            dgvBill.DataSource = BillDAO.Instance.GetBillListByDateAndPage(checkIn, checkOut,1);
        }

        //BINDING Thức Ăn
        void AddFoodBinding()
        {
            txbFoodName.DataBindings.Add(new Binding("text", dgvFood.DataSource, "Name", true, DataSourceUpdateMode.Never));
            txbFoodID.DataBindings.Add(new Binding("text", dgvFood.DataSource, "ID", true, DataSourceUpdateMode.Never));
            nmFoodPrice.DataBindings.Add(new Binding("value", dgvFood.DataSource, "Price", true, DataSourceUpdateMode.Never));
        }

        //BINDING Danh mục
        void AddCategoryBinding()
        {
            txbCategoryID.DataBindings.Add(new Binding("text", dgvCategory.DataSource, "ID", true,DataSourceUpdateMode.Never));
            txbCategoryName.DataBindings.Add(new Binding("text", dgvCategory.DataSource, "Name", true, DataSourceUpdateMode.Never));
        }
        //BINDING Bàn
        void AddTableBinding()
        {
            txbTableID.DataBindings.Add(new Binding("text", dgvTable.DataSource, "ID", true, DataSourceUpdateMode.Never));
            txbTableName.DataBindings.Add(new Binding("text", dgvTable.DataSource, "Name", true, DataSourceUpdateMode.Never));
            cbxTableStatus.DataBindings.Add(new Binding("text", dgvTable.DataSource, "Status", true, DataSourceUpdateMode.Never));
        }
        //BINDING tài khoản
        void AddAccountBinding()
        {
            txbUserName.DataBindings.Add(new Binding("text", dgvAccount.DataSource, "UserName", true, DataSourceUpdateMode.Never));
            txbDisplayName.DataBindings.Add(new Binding("text", dgvAccount.DataSource, "DisplayName", true, DataSourceUpdateMode.Never));
            nmTypeAcc.DataBindings.Add(new Binding("text", dgvAccount.DataSource,"Type",true,DataSourceUpdateMode.Never));
        }
        void LoadCategoryintoCombobox(ComboBox cb)
        {
            cb.DataSource = CategoryDAO.Instance.GetListCategory();
            cb.DisplayMember = "Name";
        }
        void LoadStatusIntoCombobox(ComboBox cb)
        {
            cb.DataSource = TableDAO.Instance.GetListTable();
            cb.DisplayMember = "Status";
        }
        #endregion
        void LoadListFood()
        {
            foodList.DataSource = FoodDAO.Instance.GetListFood();
        }
        void LoadListFoodCategory()
        {
            categoryList.DataSource = CategoryDAO.Instance.GetListFoodCategory();
        }
        void LoadListTable()
        {
            tableList.DataSource = TableDAO.Instance.GetListTable();
        }
        void LoadAccount()
        {
            accountList.DataSource = AccountDAO.Instance.GetListAccount();
        }
        #region events

        #endregion

        private void btnViewbill_Click(object sender, EventArgs e)
        {
            LoadListBillByDate(dtpkFromday.Value, dtpkToDate.Value);
        }

        private void btnShowFood_Click(object sender, EventArgs e)
        {
            LoadListFood();
        }

        private void btnShowCategory_Click(object sender, EventArgs e)
        {
            LoadListFoodCategory();
        }

        private void btnShowTable_Click(object sender, EventArgs e)
        {
            LoadListTable();
        }

        private void btnShowAccount_Click(object sender, EventArgs e)
        {
            LoadAccount();
        }

        private void txbFoodID_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (dgvFood.SelectedCells.Count > 0)
                {
                    int id = (int)dgvFood.SelectedCells[0].OwningRow.Cells["CategoryID"].Value;

                    Category category = CategoryDAO.Instance.GetCategoryByID(id);
                    cbFoodCategory.SelectedItem = category;

                    int index = -1;
                    int i = 0;
                    foreach (Category item in cbFoodCategory.Items)
                    {
                        if (item.ID == category.ID)
                        {
                            index = i;
                            break;
                        }
                        i++;
                    }
                    cbFoodCategory.SelectedIndex = index;
                }
            }
            catch { }

        }

       // Thêm sửa xóa Thức ăn
        //THÊM
        private void btnAddFood_Click(object sender, EventArgs e)
        {
            string name = txbFoodName.Text;
            int categoryID = (cbFoodCategory.SelectedItem as Category).ID;
            float price = (float)nmFoodPrice.Value;

            if (FoodDAO.Instance.InsertFood(name, categoryID, price))
            {
                MessageBox.Show("Thêm món thành công!");
                LoadListFood();
                if (insertFood != null)
                    insertFood(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Thêm món thất bại!");
            }
        }
        //SỬA
        private void btnEditFood_Click(object sender, EventArgs e)
        {

            string name = txbFoodName.Text;
            int categoryID = (cbFoodCategory.SelectedItem as Category).ID;
            float price = (float)nmFoodPrice.Value;
            int id = Convert.ToInt32(txbFoodID.Text);

            if (FoodDAO.Instance.UpdateFood(id, name, categoryID, price))
            {
                MessageBox.Show("Sửa món thành công!");
                LoadListFood();
                if (updateFood != null)
                    updateFood(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Sửa món thất bại!");
            }
        }
        //XÓA
        private void btnDelFood_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txbFoodID.Text);

            if (FoodDAO.Instance.DeleteFood(id))
            {
                MessageBox.Show("Xóa món thành công!");
                LoadListFood();
                if (deleteFood != null)
                    deleteFood(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Xóa món thất bại!");
            }
        }
      
        // Thêm sửa xóa Danh mục
        //THÊM       
        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            string name = txbCategoryName.Text;                     

            if (CategoryDAO.Instance.InsertCategory( name))
            {
                MessageBox.Show("Thêm danh mục thành công!");
                LoadListFoodCategory();               
                LoadCategoryintoCombobox(cbFoodCategory);
                if (insertCategory != null)
                    insertCategory(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Thêm danh mục thất bại!");
            }
           
        }       
        // XÓA
        private void btnDelaCategory_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txbCategoryID.Text);

            if (CategoryDAO.Instance.DeleteCategory(id))
            {
                MessageBox.Show("Xóa danh mục thành công!");
                LoadListFoodCategory();
                LoadCategoryintoCombobox(cbFoodCategory);
                if (deleteCategory != null)
                    deleteCategory(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Xóa danh mục thất bại!");
            }
        }   
        ///SỬA   
        private void btnEditCategory_Click(object sender, EventArgs e)
        {
            string name = txbCategoryName.Text;            
            int id = Convert.ToInt32(txbCategoryID.Text);

            if (CategoryDAO.Instance.UpdateCategory(name,id))
            {
                MessageBox.Show("Sửa danh mục thành công!");
                LoadListFoodCategory();
                LoadCategoryintoCombobox(cbFoodCategory);
                if (updateCategory != null)
                    updateCategory(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Sửa danh mục thất bại!");
            }
        }
        // THÊM SỬA XÓA BÀN
        //Thêm
        private void btnAddTable_Click(object sender, EventArgs e)
        {
            string name = txbTableName.Text;
            string status = cbxTableStatus.Text;

            if (TableDAO.Instance.InsertTable(name,status))
            {
                MessageBox.Show("Thêm bàn thành công!");
                LoadListTable();                
                if (insertTable != null)
                    insertTable(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Thêm bàn thất bại!");
            }
        }
        //SỬA
        private void BtnEditTable_Click(object sender, EventArgs e)
        {
            string name = txbTableName.Text;
            string status = cbxTableStatus.Text;
            int id = Convert.ToInt32(txbTableID.Text);

            if (TableDAO.Instance.UpdateTable(name,status,id))
            {
                MessageBox.Show("Sửa bàn thành công!");
                LoadListTable();                
                if (updateTable != null)
                    updateTable(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Sửa bàn thất bại!");
            }
        }
        //XÓA
        private void btnDelTable_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txbTableID.Text);

            if (TableDAO.Instance.DeleteTable(id))
            {
                MessageBox.Show("Xóa bàn thành công!");
                LoadListTable();

                if (deleteTable != null)
                    deleteTable(this, new EventArgs());
            }
            else
            {
                MessageBox.Show("Xóa bàn thất bại!");
            }
        }

        // THÊM XÓA SỬA ACCOUNT
        //Thêm
        void AddAccount(string userName, string displayName, int type)
        {
            if (AccountDAO.Instance.InsertAccount(userName, displayName, type))
            {
                MessageBox.Show("Thêm tài khoản thành công!!!");
            }
            else
            {
                MessageBox.Show("Thêm tài khoản thất bại @@");
            }
            LoadAccount();
        }
        private void btnAddAccount_Click(object sender, EventArgs e)
        {
            string userName = txbUserName.Text;
            string displayName = txbDisplayName.Text;
            int type = (int)nmTypeAcc.Value;

            AddAccount(userName, displayName, type);
        }
        //Xóa
        void DeleteAccount(string userName)
        {
            if (loginAccount.UserName.Equals(userName))
            {
                MessageBox.Show("Vui lòng đừng xóa chính bạn @@");
                return;
            }
            if (AccountDAO.Instance.DeleteAccount(userName))
            {
                MessageBox.Show("Xóa tài khoản thành công!!!");
            }
            else
            {
                MessageBox.Show("Xóa tài khoản thất bại @@");
            }
            LoadAccount();
        }
        private void btnDelAccount_Click(object sender, EventArgs e)
        {
            string userName = txbUserName.Text;

            DeleteAccount(userName);
        }
        //Sửa
        void EditAccount(string userName, string displayName, int type)
        {
            if (AccountDAO.Instance.UpdateAccount(userName, displayName, type))
            {
                MessageBox.Show("Cập nhật tài khoản thành công!!!");
            }
            else
            {
                MessageBox.Show("Cập nhật tài khoản thất bại @@");
            }
            LoadAccount();
        }
        private void btnEditAccount_Click(object sender, EventArgs e)
        {
            string userName = txbUserName.Text;
            string displayName = txbDisplayName.Text;
            int type = (int)nmTypeAcc.Value;

            EditAccount(userName, displayName, type);
        }
        void ResetPass(string userName)
        {
            if (AccountDAO.Instance.ResetPassword(userName))
            {
                MessageBox.Show("Đặt lại mật khẩu thành công!!!");
            }
            else
            {
                MessageBox.Show("Đặt lại mật khẩu thất bại @@");
            }
        }
        private void btnResetPassword_Click(object sender, EventArgs e)
        {
            string userName = txbUserName.Text;

            ResetPass(userName);
        }
        private event EventHandler insertFood;
        public event EventHandler InsertFood
        {
            add { insertFood += value; }
            remove { insertFood -= value; }
        }

        private event EventHandler deleteFood;
        public event EventHandler DeleteFood
        {
            add { deleteFood += value; }
            remove { deleteFood -= value; }
        }
        private event EventHandler updateFood;
        public event EventHandler UpdateFood
        {
            add { updateFood += value; }
            remove { updateFood -= value; }
        }
        //

        private event EventHandler insertCategory;
        public event EventHandler InsertCategory
        {
            add { insertCategory += value; }
            remove { insertCategory -= value; }
        }
        private event EventHandler deleteCategory;
        public event EventHandler DeleteCategory
        {
            add { deleteCategory += value; }
            remove { deleteCategory -= value; }
        }
        private event EventHandler updateCategory;
        public event EventHandler UpdateCategory
        {
            add { updateCategory += value; }
            remove { updateCategory -= value; }
        }

        //
        private event EventHandler insertTable;
        public event EventHandler InsertTable
        {
            add { insertTable += value; }
            remove { insertTable -= value; }
        }
        private event EventHandler deleteTable;
        public event EventHandler DeleteTable
        {
            add { deleteTable += value; }
            remove { deleteTable -= value; }
        }
        private event EventHandler updateTable;
        public event EventHandler UpdateTable
        {
            add { updateTable += value; }
            remove { updateTable -= value; }
        }


        private void btnSearchFood_Click(object sender, EventArgs e)
        {
            foodList.DataSource = SearchFoodByName(txtSearchFoodName.Text);
        }

        private void btnFirstBillPage_Click(object sender, EventArgs e)
        {
            txtPageBill.Text = "1";
            btnNextBillPage.Enabled = true;
            btnPrevBillPage.Enabled = false;
        }

        private void btnLastBillPage_Click(object sender, EventArgs e)
        {
            int sumRecord = BillDAO.Instance.GetNumBillListByDate(dtpkFromday.Value, dtpkToDate.Value);

            int lastPage = sumRecord / 10;

            if (sumRecord % 10 != 0)
                lastPage++;
            txtPageBill.Text = lastPage.ToString();
            btnNextBillPage.Enabled = false;
            btnPrevBillPage.Enabled = true;
        }

        private void txtPageBill_TextChanged(object sender, EventArgs e)
        {
            dgvBill.DataSource = BillDAO.Instance.GetBillListByDateAndPage(dtpkFromday.Value, dtpkToDate.Value, Convert.ToInt32(txtPageBill.Text));

        }

        private void btnPrevBillPage_Click(object sender, EventArgs e)
        {
            int page = Convert.ToInt32(txtPageBill.Text);
            int sumRecord = BillDAO.Instance.GetNumBillListByDate(dtpkFromday.Value, dtpkToDate.Value);
            if (page > 1)
                page--;
            txtPageBill.Text = page.ToString();
            if (sumRecord % 10 != 0)
            {
                if (page < ((sumRecord / 10) + 1))
                    btnNextBillPage.Enabled = true;
            }
            if (page == 1)
                btnPrevBillPage.Enabled = false;

        }

        private void btnNextBillPage_Click(object sender, EventArgs e)
        {
            int page = Convert.ToInt32(txtPageBill.Text);
            int sumRecord = BillDAO.Instance.GetNumBillListByDate(dtpkFromday.Value, dtpkToDate.Value);

            if (page < sumRecord)
                page++;
            txtPageBill.Text = page.ToString();    
            if(sumRecord % 10 != 0 )
            {
                if (page == ((sumRecord / 10) + 1))
                    btnNextBillPage.Enabled = false;                
            }
            if (Convert.ToInt32(txtPageBill.Text) > 1)
            {
                btnPrevBillPage.Enabled = true;
            }
        }
            
    }

}
