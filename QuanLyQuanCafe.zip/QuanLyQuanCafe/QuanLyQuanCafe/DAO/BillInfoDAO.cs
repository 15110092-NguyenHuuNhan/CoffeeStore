﻿using QuanLyQuanCafe.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanCafe.DAO
{
    public class BillInfoDAO    //lấy list bill từ BillID
    {
        private static BillInfoDAO instance;

            //singleton  
            //Tại 1 thời điểm chỉ dc có 1 connection dc kết nối
        public static BillInfoDAO Instance       
        {
            get
            {
                if (instance == null) instance = new BillInfoDAO();
                return instance;
            }

            private set
            {
                instance = value;
            }        
            
        }
        private BillInfoDAO() { }

        public void DeleteBillInfoByFoodID(int id)
        {
            DataProvider.Instance.ExecuteNonQuery("delete BillInfo where idFood = " + id);
        }

        public List<BillInfo> GetListBillInfo(int id)   //lấy billinfo theo id của Bill
        {
            List<BillInfo> listBillInfo = new List<BillInfo>();
            DataTable data = DataProvider.Instance.ExecuteQuery("select * from BillInfo where idBill = "+id ); //lấy dữ liệu trong BillInfo 
            //Đổ dữ liệu vào listBill
            foreach (DataRow item in data.Rows)
            {
                BillInfo info = new BillInfo(item);
                listBillInfo.Add(info);
            }

            return listBillInfo;
        }

        public void InsertBillInfo(int idBill,int idFood,int idCount)
        {
            DataProvider.Instance.ExecuteNonQuery("exec USP_InsertBillInfo @idBill , @idFood , @count ", new object[] { idBill, idFood, idCount });
        }
    }
}
