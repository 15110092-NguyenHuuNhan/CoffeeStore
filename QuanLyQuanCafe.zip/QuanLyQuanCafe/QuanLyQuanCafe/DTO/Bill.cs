﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanCafe.DTO
{
    public class Bill
    {
        //Constructor
        public Bill(int id,DateTime? dateCheckIn,DateTime? dateCheckOut,int status,float totalPrice, int discount = 0)
        {
            this.ID = id;
            this.DateCheckIn = dateCheckIn;
            this.DateCheckOut = dateCheckOut;
            this.Status  = status;
            this.TotalPrice = totalPrice;
            this.Discount = discount;
        }
        public Bill(DataRow row)
        {
            this.iD = (int)row["id"];
            this.dateCheckIn = (DateTime?)row["dateCheckIn"];

            var dateCheckOutTemp = row["dateCheckOut"];      //trường hợp dateCheckOut == null
            if(dateCheckOutTemp.ToString() != "")               //nếu dateCheckOut trả về rỗng ""
                this.dateCheckOut = (DateTime?)dateCheckOutTemp; //thì dateChaeckOut null

            this.Status = (int)row["status"];
            if (row["discount"].ToString() != "")
                this.Discount = (int)row["discount"];
        }
        private int discount;

        private float totalPrice;
        private int iD;
        private DateTime? dateCheckIn;      //cho phép null
        private DateTime? dateCheckOut;      //cho phép null
        private int status;
        public int ID
        {
            get{return iD;}
            set {iD = value; }       
        }

        public int Discount
        {
            get { return discount; }
            set { discount = value; }
        }
        public int Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }

        public DateTime? DateCheckOut
        {
            get
            {
                return dateCheckOut;
            }

            set
            {
                dateCheckOut = value;
            }
        }

        public DateTime? DateCheckIn
        {
            get
            {
                return dateCheckIn;
            }

            set
            {
                dateCheckIn = value;
            }
        }

        public float TotalPrice
        {
            get
            {
                return totalPrice;
            }

            set
            {
                totalPrice = value;
            }
        }
    }
}
              
            
            

            
